export const EPUBJS_VERSION: string;

export const DOM_EVENTS: Array<string>;

export const EVENTS: {
  [key: string]: {
    [key: string]: string
  }
}
