Popr
----

Popr is a small and simple popup menu jQuery plugin. It works on almost any element.

To get started, see <http://www.tipue.com/popr/>. There's a demo at <http://www.tipue.com/popr/>.

Documentation
-------------

There's full documentation at <http://www.tipue.com/popr/>.

Copyright and license
---------------------

Popr Copyright (c) 2015 Tipue, under the The MIT License.



