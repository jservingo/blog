# videoplayer
mobile h5 audio player with DIY style based on jquery

### DIY

我们一般都看不到Audio的样式，基本都被隐藏了。因为对于新时代的我们来说，暂时还没有get它的美。

但是，我们要控制音频的播放，直观的看到时间进度等，那就需要展示这东西了。世上没有丑audio，只有懒audio.

我们给它化个妆就好了。淡妆，淡妆。

### Code

基于jQuery

### Use

    $(selector).initAudioPlayer();  // select 为audio元素，可以初始化多个

播放器样式是写在js代码里的，如果有需要，可以把代码抠出来放在CSS文件里。然后再化成自己喜欢的样子。或者你产品经理喜欢的样子。

### DEMO

[来个demo][1]，PC 打开为移动端模式。

手机扫描二维码：

![audio-player][2]

  [1]: https://xiaohuazheng.github.io/demos/2018-06-02-audio-player-demo.html
  [2]: https://xiaohuazheng.github.io/img/qrCode/audio-player.png


